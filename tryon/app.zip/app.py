from flask import Flask, request, jsonify, send_from_directory, render_template_string
from flask_cors import CORS
from gradio_client import Client, handle_file
import os
import shutil
from datetime import datetime
from werkzeug.utils import secure_filename
import uuid

app = Flask(__name__)
CORS(app)

# ===== 重要：設定你的 Hugging Face Token =====
# 請到 https://huggingface.co/settings/tokens 取得你的 token
# 方法1：直接在程式中設定（較簡單）
HF_TOKEN = "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"  # 請替換成你的實際 token

# 方法2：使用環境變數（較安全）
# 在命令行中執行：export HUGGINGFACE_TOKEN=your_token_here
# 然後取消下面這行的註解，並註解掉上面的 HF_TOKEN 行
# HF_TOKEN = os.getenv('HUGGINGFACE_TOKEN')

# 設定路徑
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
UPLOAD_DIR = os.path.join(BASE_DIR, 'uploads')
RESULTS_DIR = os.path.join(BASE_DIR, 'results')

# 建立必要的資料夾
for directory in [UPLOAD_DIR, RESULTS_DIR]:
    if not os.path.exists(directory):
        os.makedirs(directory)

# 允許的檔案類型
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'bmp'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# 首頁路由 - 提供前端介面
@app.route('/')
def index():
    # 讀取 HTML 檔案
    html_file = os.path.join(BASE_DIR, 'index.html')
    try:
        with open(html_file, 'r', encoding='utf-8') as f:
            return f.read()
    except FileNotFoundError:
        return '''
        <h1>找不到前端檔案</h1>
        <p>請確保 index.html 檔案在同一個資料夾中</p>
        <p>或者將前端 HTML 內容儲存為 index.html</p>
        '''

# 虛擬試衣 API
@app.route('/api/tryon', methods=['POST'])
def tryon_api():
    try:
        # 檢查 Token 是否設定
        if not HF_TOKEN or HF_TOKEN == "hf_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx":
            return jsonify({
                'success': False, 
                'error': '請先設定 Hugging Face Token！\n請到 https://huggingface.co/settings/tokens 取得 token，\n然後在程式碼中替換 HF_TOKEN 的值。'
            })
        
        # 檢查檔案
        if 'personFile' not in request.files or 'garmentFile' not in request.files:
            return jsonify({'success': False, 'error': '缺少必要的圖片檔案'})
        
        person_file = request.files['personFile']
        garment_file = request.files['garmentFile']
        
        if person_file.filename == '' or garment_file.filename == '':
            return jsonify({'success': False, 'error': '檔案名稱無效'})
        
        if not (allowed_file(person_file.filename) and allowed_file(garment_file.filename)):
            return jsonify({'success': False, 'error': '不支援的檔案格式'})
        
        # 生成唯一檔名
        session_id = str(uuid.uuid4())[:8]
        person_filename = f"{session_id}_person.{person_file.filename.rsplit('.', 1)[1].lower()}"
        garment_filename = f"{session_id}_garment.{garment_file.filename.rsplit('.', 1)[1].lower()}"
        
        # 儲存上傳的檔案
        person_path = os.path.join(UPLOAD_DIR, person_filename)
        garment_path = os.path.join(UPLOAD_DIR, garment_filename)
        
        person_file.save(person_path)
        garment_file.save(garment_path)
        
        # 使用預設參數（移除進階設定）
        garment_desc = 'A beautiful garment'
        denoise_steps = 30
        seed = 42
        auto_mask = True
        crop_image = False
        
        print(f"開始處理虛擬試衣...")
        print(f"人體圖片: {person_path}")
        print(f"服裝圖片: {garment_path}")
        print(f"使用 Token: {HF_TOKEN[:10]}...")
        
        # 連接 IDM-VTON API（使用 Token）
        try:
            client = Client("yisol/IDM-VTON", hf_token=HF_TOKEN)
            print("✅ 成功連接 IDM-VTON API")
        except Exception as e:
            print(f"❌ 連接 API 失敗: {e}")
            return jsonify({
                'success': False, 
                'error': f'連接 IDM-VTON API 失敗: {str(e)}\n請檢查你的 Hugging Face Token 是否正確。'
            })
        
        # 執行虛擬試衣
        result = client.predict(
            {"background": handle_file(person_path), "layers": [], "composite": None},
            handle_file(garment_path),
            garment_desc,
            auto_mask,
            crop_image,
            denoise_steps,
            seed,
            api_name="/tryon"
        )
        
        print(f"API 回應: {result}")
        
        # 取得結果圖片路徑
        output_image_path = result[0]
        
        # 產生結果檔名
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        result_filename = f"tryon_result_{session_id}_{timestamp}.jpg"
        result_path = os.path.join(RESULTS_DIR, result_filename)
        
        # 複製結果圖片
        shutil.copy2(output_image_path, result_path)
        
        print(f"結果已儲存: {result_path}")
        
        # 清理暫存檔案
        try:
            os.remove(person_path)
            os.remove(garment_path)
        except:
            pass
        
        # 回傳結果
        return jsonify({
            'success': True,
            'resultUrl': f'/results/{result_filename}',
            'message': '虛擬試衣完成！'
        })
        
    except Exception as e:
        print(f"錯誤: {str(e)}")
        
        # 特別處理配額相關錯誤
        error_msg = str(e)
        if "quota" in error_msg.lower() or "exceeded" in error_msg.lower():
            error_msg += "\n\n💡 建議解決方案:\n1. 等待24小時後再試\n2. 升級到 Hugging Face Pro ($9/月)\n3. 降低 denoise_steps 參數節省時間"
        
        return jsonify({
            'success': False,
            'error': f'處理失敗: {error_msg}'
        })

# 提供結果圖片
@app.route('/results/<filename>')
def get_result(filename):
    return send_from_directory(RESULTS_DIR, filename)

# 提供上傳圖片（如果需要）
@app.route('/uploads/<filename>')
def get_upload(filename):
    return send_from_directory(UPLOAD_DIR, filename)

# 取得結果列表
@app.route('/api/results')
def list_results():
    try:
        files = []
        for filename in os.listdir(RESULTS_DIR):
            if filename.lower().endswith(('.png', '.jpg', '.jpeg')):
                file_path = os.path.join(RESULTS_DIR, filename)
                files.append({
                    'filename': filename,
                    'url': f'/results/{filename}',
                    'created': datetime.fromtimestamp(os.path.getctime(file_path)).strftime('%Y-%m-%d %H:%M:%S')
                })
        
        # 按建立時間排序（最新的在前）
        files.sort(key=lambda x: x['created'], reverse=True)
        
        return jsonify({'success': True, 'files': files})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

# 檢查 Token 狀態的 API
@app.route('/api/check-token')
def check_token():
    try:
        if not HF_TOKEN or HF_TOKEN == "hf_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx":
            return jsonify({
                'success': False, 
                'message': '未設定 Hugging Face Token',
                'instructions': '請到 https://huggingface.co/settings/tokens 取得 token'
            })
        
        # 嘗試連接 API 來驗證 Token
        client = Client("yisol/IDM-VTON", hf_token=HF_TOKEN)
        return jsonify({
            'success': True, 
            'message': 'Token 驗證成功！',
            'token_preview': f"{HF_TOKEN[:10]}..."
        })
    except Exception as e:
        return jsonify({
            'success': False, 
            'message': f'Token 驗證失敗: {str(e)}'
        })

if __name__ == '__main__':
    print("🎨 口袋造型師伺服器啟動中...")
    print(f"📁 上傳資料夾: {UPLOAD_DIR}")
    print(f"📁 結果資料夾: {RESULTS_DIR}")
    
    # 檢查 Token 狀態
    if not HF_TOKEN or HF_TOKEN == "hf_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx":
        print("⚠️  警告：未設定 Hugging Face Token！")
        print("📝 請到 https://huggingface.co/settings/tokens 取得 token")
        print("🔧 然後在程式碼第15行替換 HF_TOKEN 的值")
    else:
        print(f"✅ 已設定 HF Token: {HF_TOKEN[:10]}...")
    
    print("🌐 請在瀏覽器中開啟: http://localhost:5000")
    print("⚠️  請確保已安裝 Flask 和 flask-cors:")
    print("   pip install flask flask-cors")
    
    app.run(debug=True, host='0.0.0.0', port=5000)